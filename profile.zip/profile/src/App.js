import logo from './logo.svg';
import './App.css';
import AdminProfileForm from './AdminProfile';
import StudentProfileForm from './StudentProfile';
import TeacherProfileForm from './TeacherProfile';

function App() {
  return (
    <div className="App">
     <TeacherProfileForm/>
    </div>
  );
}

export default App;
