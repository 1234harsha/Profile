import React, { useState } from 'react';
import './AdminProfileForm.css'; // Importing the same CSS file

const StudentProfileForm = ({ onUpdateStudent }) => {
  const [formData, setFormData] = useState({
    rollNo: '',
    firstName: '',
    lastName: '',
    email: '',
    dob: '',
    gender: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onUpdateStudent(formData);
  };

  return (
    <div className="container mt-4">
      <div className="form-container">
        <h2 className="form-title">Student Profile Form</h2>
        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label className="form-label">Roll No:</label>
                <input
                  type="text"
                  className="form-control"
                  name="rollNo"
                  value={formData.rollNo}
                  onChange={handleChange}
                  disabled 
                />
              </div>
              <div className="form-group">
                <label className="form-label">First Name:</label>
                <input
                  type="text"
                  className="form-control"
                  name="firstName"
                  placeholder="Enter first name"
                  value={formData.firstName}
                  onChange={handleChange}
                  disabled 
                />
              </div>
              <div className="form-group">
                <label className="form-label">Last Name:</label>
                <input
                  type="text"
                  className="form-control"
                  name="lastName"
                  placeholder="Enter last name"
                  value={formData.lastName}
                  onChange={handleChange}
                  disabled 
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label className="form-label">Email:</label>
                <input
                  type="email"
                  className="form-control"
                  name="email"
                  placeholder="Enter email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Date of Birth:</label>
                <input
                  type="date"
                  className="form-control"
                  name="dob"
                  placeholder="Select date of birth"
                  value={formData.dob}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Gender:</label>
                <select
                  className="form-control"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                >
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
          </div>
          <br/>
          <div className="text-center">
            <button type="submit" className="btn btn-primary">Update</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default StudentProfileForm;
